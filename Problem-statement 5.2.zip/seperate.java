import java.io.*;

public class seperate
{
	public static void main(String args[])
	{
		String Str = new String("23 + 45 - ( 343 / 12 )");

		
		for (String val: Str.split(" "))
			System.out.println(val);

		System.out.println("");

		
	}
}
