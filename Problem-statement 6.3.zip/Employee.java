import java.util. Vector;
public class Employee {

private int empid;

private String ename, address;

public Employee (int empid, String ename, String address) {

super();

this.empid = empid;

this.ename = ename;

this.address = address;
}

public int getEmpid () {

return empid;

}

public void setEmpid (int empid) {

this.empid = empid;
}

public String getEname() {

return ename;

}

public void setEname (String ename) {
 this.ename = ename;
}
public String getAddress (){

return address;

}

public void setAddress (String address) {

this.address = address;

}
}



public class TestEmployeeCollection {

public static void main(String[] args) {

Vector<Employee> v =addInput(); 
display (v);
 }

public static Vector<Employee> addInput ()
{

Employee el=new Employee (101, "siddartha", "bangalore");

Employee e2=new Employee (101, "bharat", "mysore");

Employee e3=new Employee (103, "rohith", "bellary");
Vector<Employee> v = new Vector<Employee> ();

v.add (el);

v.add (e2);

v.add (e3);

return v;

}

public static void display (Vector<Employee>v)
{
for (Employee e:v)
{
System.out.println (e.getEmpid ()+"\t"+e.getEname()+"\t"+e.getAddress());
}
}
}