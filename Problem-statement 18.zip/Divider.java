public class Divider {

    private static final String DOT = ".";
    private static final String ERROR = "ERROR";
    private static final String LEFT_PARENTHESIS = "(";
    private static final String RIGHT_PARENTHESIS = ")";

    public static String divide(final int a, final int b){
        if (b == 0) {
            return ERROR;
        }

        int value = a / b;
        int remainder = a % b;
        return String.valueOf(value) + DOT + divider(remainder, b);
    }

    private static String divider(final int a, final int b) {
        final Map<Integer, Integer> remainderIndexMap = new HashMap<>();
        final List<Integer> values = new ArrayList<>();

        int value;
        int remainder = a;
        while (!remainderIndexMap.containsKey(remainder)) {
            remainderIndexMap.put(remainder, values.size());

            remainder *= 10;
            value = remainder / b;
            remainder = remainder % b;
            values.add(value);
        }

        final int index = remainderIndexMap.get(remainder);
        final StringBuilder result = new StringBuilder();
        for (int i = 0; i < index; i++) {
            result.append(values.get(i));
        }
        result.append(LEFT_PARENTHESIS);
        for (int i = index; i < values.size(); i++) {
            result.append(values.get(i));
        }
        result.append(RIGHT_PARENTHESIS);
        return result.toString();
    }
}